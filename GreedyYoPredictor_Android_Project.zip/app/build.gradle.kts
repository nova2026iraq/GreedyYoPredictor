plugins { id("com.android.application") }

android {
    namespace = "com.greedyyopredictor"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.greedyyopredictor"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.mlkit:text-recognition:16.0.1")
}
