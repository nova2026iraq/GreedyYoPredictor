package com.greedyyopredictor;

import android.app.*;
import android.content.*;
import android.graphics.PixelFormat;
import android.os.*;
import android.view.*;
import android.widget.*;

public class FloatingService extends Service {
    private WindowManager wm; private View panel;
    @Override public IBinder onBind(Intent i) { return null; }
    @Override public void onCreate() {
        super.onCreate(); wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        TextView t=new TextView(this);
        t.setText("GY Predictor\nبانتظار قراءة سجل النتائج…");
        t.setTextColor(0xFFFFFFFF); t.setTextSize(14); t.setPadding(22,16,22,16);
        t.setBackgroundColor(0xEE35146A); panel=t;
        int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        p.gravity=Gravity.TOP|Gravity.END; p.x=18; p.y=180;
        try { wm.addView(panel,p); } catch(Exception ignored) {}
    }
    @Override public void onDestroy(){ if(panel!=null) try{wm.removeView(panel);}catch(Exception ignored){} super.onDestroy(); }
}
