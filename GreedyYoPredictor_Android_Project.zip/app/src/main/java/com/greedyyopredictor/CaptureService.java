package com.greedyyopredictor;

import android.app.*;
import android.content.*;
import android.media.projection.*;
import android.os.*;

public class CaptureService extends Service {
    private MediaProjection projection;
    @Override public IBinder onBind(Intent i){ return null; }
    @Override public int onStartCommand(Intent i,int flags,int id){
        createChannel();
        startForeground(9,new Notification.Builder(this,"capture")
            .setContentTitle("Greedy Yo Predictor")
            .setContentText("إذن قراءة الشاشة مفعّل لهذه الجلسة")
            .setSmallIcon(android.R.drawable.ic_menu_view).build());
        if(i!=null && i.hasExtra("data")){
            int code=i.getIntExtra("resultCode",0);
            Intent data=(Intent)i.getParcelableExtra("data");
            MediaProjectionManager m=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
            projection=m.getMediaProjection(code,data);
        }
        return START_NOT_STICKY;
    }
    private void createChannel(){
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel c=new NotificationChannel("capture","Screen reading",NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }
    @Override public void onDestroy(){ if(projection!=null) projection.stop(); super.onDestroy(); }
}
