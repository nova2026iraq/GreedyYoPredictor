package com.greedyyopredictor;

import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.*;

public class MainActivity extends Activity {
    private static final int REQUEST_CAPTURE = 701;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(1); root.setPadding(32, 40, 32, 24);
        root.setBackgroundColor(0xFF180B2D);
        TextView title = new TextView(this);
        title.setText("Greedy Yo Predictor");
        title.setTextColor(0xFFFFFFFF); title.setTextSize(26);
        root.addView(title);
        TextView info = new TextView(this);
        info.setText("محلل لعبة المزرعة\n\n1) اسمح بالنافذة العائمة.\n2) ابدأ التقاط الشاشة بموافقتك.\n3) افتح Hello Yo واترك المحلل يقرأ الشاشة.\n\nتنبيه: التوقعات إحصائية وليست ضماناً للنتيجة.");
        info.setTextColor(0xFFE8DDFB); info.setTextSize(17);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, -2); ip.topMargin=28;
        root.addView(info, ip);
        Button overlay = new Button(this); overlay.setText("تفعيل النافذة العائمة");
        overlay.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this))
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
            else startService(new Intent(this, FloatingService.class));
        });
        root.addView(overlay);
        Button capture = new Button(this); capture.setText("السماح بقراءة الشاشة");
        capture.setOnClickListener(v -> {
            MediaProjectionManager m = (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
            startActivityForResult(m.createScreenCaptureIntent(), REQUEST_CAPTURE);
        });
        root.addView(capture);
        setContentView(root);
    }
    @Override protected void onActivityResult(int req, int result, Intent data) {
        super.onActivityResult(req, result, data);
        if (req == REQUEST_CAPTURE && result == RESULT_OK) {
            Intent s = new Intent(this, CaptureService.class);
            s.putExtra("resultCode", result); s.putExtra("data", data);
            startForegroundService(s);
            Toast.makeText(this, "تم منح إذن التقاط الشاشة لهذه الجلسة", Toast.LENGTH_LONG).show();
        }
    }
}
