package com.greedyyopredictor;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import java.util.*;

public class MainActivity extends Activity {
    private EditText input;
    private TextView result;
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density); }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(22), dp(18), dp(18));
        root.setBackgroundColor(Color.rgb(12, 18, 30));

        TextView title = text("GreedyYoPredictor", 25, Color.WHITE, true);
        root.addView(title);
        TextView subtitle = text("المحلل الإحصائي المتقدم", 17, Color.rgb(126,180,255), true);
        root.addView(subtitle);
        TextView info = text("أدخل النتائج السابقة مفصولة بفواصل أو مسافات. التحليل وصفي للبيانات المدخلة ولا يتنبأ بنتائج عشوائية.", 14, Color.LTGRAY, false);
        info.setPadding(0, dp(12), 0, dp(12)); root.addView(info);

        input = new EditText(this);
        input.setHint("مثال: 2, 4, 1, 3, 2, 2, 5");
        input.setTextColor(Color.WHITE); input.setHintTextColor(Color.GRAY);
        input.setMinLines(3); input.setGravity(Gravity.TOP);
        input.setPadding(dp(12), dp(12), dp(12), dp(12));
        input.setBackgroundColor(Color.rgb(30, 39, 55));
        root.addView(input, new LinearLayout.LayoutParams(-1, dp(120)));

        Button analyze = button("حلّل البيانات");
        root.addView(analyze);
        analyze.setOnClickListener(v -> runAnalysis());

        Button floating = button("تشغيل النافذة العائمة");
        root.addView(floating);
        floating.setOnClickListener(v -> startFloating());

        result = text("ستظهر نتائج التحليل هنا.", 15, Color.WHITE, false);
        result.setPadding(dp(12), dp(14), dp(12), dp(14));
        result.setBackgroundColor(Color.rgb(24, 33, 48));
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, 0, 1);
        rp.topMargin = dp(14); root.addView(result, rp);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        setContentView(scroll);
    }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        t.setPadding(0, dp(5), 0, dp(5)); return t;
    }
    private Button button(String s) {
        Button b = new Button(this); b.setText(s); b.setTextSize(15);
        b.setTextColor(Color.WHITE); b.setAllCaps(false);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(35, 105, 190)));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(52));
        p.topMargin = dp(9); b.setLayoutParams(p); return b;
    }

    private void runAnalysis() {
        String raw = input.getText().toString().trim();
        String[] parts = raw.split("[,،;；\\s]+");
        ArrayList<Double> a = new ArrayList<>();
        for (String p : parts) {
            if (p.isEmpty()) continue;
            try { a.add(Double.parseDouble(p)); } catch (Exception ignored) {}
        }
        if (a.size() < 3) {
            result.setText("أدخل 3 قيم رقمية على الأقل حتى يكون التحليل مفيداً.");
            return;
        }
        int n = a.size();
        double sum = 0, min = Double.POSITIVE_INFINITY, max = Double.NEGATIVE_INFINITY;
        HashMap<Double,Integer> freq = new HashMap<>();
        for (double x : a) { sum += x; min = Math.min(min,x); max = Math.max(max,x); freq.put(x, freq.getOrDefault(x,0)+1); }
        double mean = sum/n, variance = 0;
        for (double x : a) variance += (x-mean)*(x-mean);
        variance /= n;
        double sd = Math.sqrt(variance);
        ArrayList<Double> sorted = new ArrayList<>(a); Collections.sort(sorted);
        double median = n%2==1 ? sorted.get(n/2) : (sorted.get(n/2-1)+sorted.get(n/2))/2.0;
        double entropy = 0;
        for (int c : freq.values()) { double p = (double)c/n; entropy -= p*(Math.log(p)/Math.log(2)); }
        double changes = 0;
        for (int i=1;i<n;i++) if (!a.get(i).equals(a.get(i-1))) changes++;
        double changeRate = changes/(n-1)*100.0;
        double longest = 1, streak = 1;
        for (int i=1;i<n;i++) { if (a.get(i).equals(a.get(i-1))) streak++; else streak=1; longest=Math.max(longest,streak); }
        ArrayList<Map.Entry<Double,Integer>> ranked = new ArrayList<>(freq.entrySet());
        ranked.sort((x,y) -> Integer.compare(y.getValue(), x.getValue()));
        StringBuilder top = new StringBuilder();
        for (int i=0;i<Math.min(8,ranked.size());i++) {
            if (i>0) top.append("، ");
            top.append(fmt(ranked.get(i).getKey())).append(" (").append(ranked.get(i).getValue()).append(")");
        }
        StringBuilder out = new StringBuilder();
        out.append("ملخص العينة\n");
        out.append("عدد القيم: ").append(n).append("\n");
        out.append("المتوسط: ").append(fmt(mean)).append(" | الوسيط: ").append(fmt(median)).append("\n");
        out.append("أقل قيمة: ").append(fmt(min)).append(" | أعلى قيمة: ").append(fmt(max)).append("\n");
        out.append("الانحراف المعياري: ").append(fmt(sd)).append("\n");
        out.append("تنوع المعلومات (Entropy): ").append(fmt(entropy)).append(" بت\n");
        out.append("معدل تغيّر القيمة بين الخطوات: ").append(fmt(changeRate)).append("%\n");
        out.append("أطول تكرار متتالٍ للقيمة نفسها: ").append((int)longest).append("\n\n");
        out.append("الأكثر ظهوراً (قيميّاً):\n").append(top).append("\n\n");
        out.append("قراءة إحصائية: ");
        if (sd < 0.000001) out.append("كل القيم متطابقة تقريباً؛ العينة لا تعرض تبايناً.");
        else if (changeRate < 35) out.append("يوجد تكرار متتالٍ ملحوظ في هذه العينة.");
        else out.append("توجد تغيّرات متكررة بين القيم في هذه العينة.");
        out.append("\n\nتنبيه: التكرار السابق لا يجعل القيمة أكثر احتمالاً في الجولة القادمة إذا كانت النتائج مستقلة وعشوائية. لا تستخدم هذا التقرير كضمان للفوز أو الربح.");
        result.setText(out.toString());
    }
    private String fmt(double d) {
        if (Math.abs(d-Math.rint(d)) < 0.000001) return String.valueOf((long)Math.rint(d));
        return String.format(Locale.US, "%.3f", d);
    }
    private void startFloating() {
        if (!Settings.canDrawOverlays(this)) {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()));
            startActivity(i);
            Toast.makeText(this, "فعّل السماح بالظهور فوق التطبيقات ثم ارجع واضغط الزر مرة أخرى.", Toast.LENGTH_LONG).show();
            return;
        }
        startService(new Intent(this, FloatingOverlayService.class));
        Toast.makeText(this, "تم تشغيل النافذة العائمة.", Toast.LENGTH_SHORT).show();
    }
}
