package com.greedyyopredictor;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.graphics.Color;
import android.os.IBinder;
import android.view.*;
import android.widget.*;

public class FloatingOverlayService extends Service {
    private WindowManager wm;
    private View bubble;
    @Override public IBinder onBind(Intent i) { return null; }
    @Override public void onCreate() {
        super.onCreate();
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        TextView v = new TextView(this);
        v.setText("تحليل");
        v.setTextColor(Color.WHITE); v.setTextSize(14); v.setGravity(Gravity.CENTER);
        v.setPadding(22, 14, 22, 14); v.setBackgroundColor(Color.rgb(30,100,180));
        bubble = v;
        int type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.RIGHT; p.x = 18; p.y = 220;
        v.setOnClickListener(view -> {
            Intent open = new Intent(this, MainActivity.class);
            open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(open);
        });
        v.setOnTouchListener(new View.OnTouchListener() {
            int ix, iy; float sx, sy;
            public boolean onTouch(View view, MotionEvent e) {
                if (e.getAction()==MotionEvent.ACTION_DOWN) { ix=p.x; iy=p.y; sx=e.getRawX(); sy=e.getRawY(); return false; }
                if (e.getAction()==MotionEvent.ACTION_MOVE) {
                    p.x=ix+(int)(sx-e.getRawX()); p.y=iy+(int)(e.getRawY()-sy);
                    wm.updateViewLayout(bubble,p); return true;
                }
                return false;
            }
        });
        wm.addView(v,p);
    }
    @Override public void onDestroy() {
        if (wm!=null && bubble!=null) { try { wm.removeView(bubble); } catch(Exception ignored) {} }
        super.onDestroy();
    }
}
