plugins {
    id("com.android.application")
}
android {
    namespace = "com.greedyyopredictor"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.greedyyopredictor"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
